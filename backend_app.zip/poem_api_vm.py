from flask import Flask, request, jsonify
from flask_cors import CORS
from google.cloud import storage
import os
import shutil
import torch
from transformers import GPT2LMHeadModel, GPT2Tokenizer

app = Flask(__name__)
CORS(app)

# MODEL_DIR_LOCAL = "/app/model_cache"
# GCS_MODEL_BUCKET = "gen-poem-ancnt-models-459915"
# GCS_MODEL_PREFIX = "models/gpt2_viet_poem_final_pytorch/"
GCS_MODEL_BUCKET = "gen-poem-ancnt-models-459915"
GCS_MODEL_PREFIX = "models/gpt2_viet_poem_final_pytorch/" 
MODEL_DIR_LOCAL = os.path.expanduser("~/model_cache_gen_poem") 

model = None
tokenizer = None
device = "cuda" if torch.cuda.is_available() else "cpu"

def download_model_from_gcs(bucket_name, source_blob_prefix, destination_directory):
    if os.path.exists(os.path.join(destination_directory, "config.json")):
        print(f"Model found in {destination_directory}. Skipping download.")
        return True

    os.makedirs(destination_directory, exist_ok=True)

    try:
        storage_client = storage.Client()
        bucket = storage_client.bucket(bucket_name)
        blobs = list(bucket.list_blobs(prefix=source_blob_prefix))

        if not blobs:
            print(f"No blobs found at gs://{bucket_name}/{source_blob_prefix}")
            return False

        print(f"Downloading model from gs://{bucket_name}/{source_blob_prefix} to {destination_directory}...")
        for blob in blobs:
            if blob.name.endswith("/"):
                continue

            file_path_relative_to_prefix = os.path.relpath(blob.name, source_blob_prefix)
            destination_file_name = os.path.join(destination_directory, file_path_relative_to_prefix)

            os.makedirs(os.path.dirname(destination_file_name), exist_ok=True)

            blob.download_to_filename(destination_file_name)
            print(f"Downloaded {blob.name} to {destination_file_name}")
        print("Model download complete.")
        return True
    except Exception as e:
        print(f"Error downloading model from GCS: {e}")
        return False

def load_model_and_tokenizer():
    global model, tokenizer
    if download_model_from_gcs(GCS_MODEL_BUCKET, GCS_MODEL_PREFIX, MODEL_DIR_LOCAL):
        try:
            print(f"Loading model from {MODEL_DIR_LOCAL}...")
            tokenizer = GPT2Tokenizer.from_pretrained(MODEL_DIR_LOCAL)
            model = GPT2LMHeadModel.from_pretrained(MODEL_DIR_LOCAL)
            model.to(device)
            model.eval()
            print(f"Model loaded successfully on {device}.")
        except Exception as e:
            print(f"Error loading model/tokenizer: {e}")
            model = None
            tokenizer = None
    else:
        print("Failed to download model. API cannot function.")

@app.route('/generate', methods=['POST'])
def generate_poem_route():
    global model, tokenizer
    if model is None or tokenizer is None:
        return jsonify({"error": "Model not loaded. Please check server logs."}), 500

    try:
        data = request.get_json()
        prompt = data.get('prompt')
        temperature = float(data.get('temperature', 0.8))
        max_length = int(data.get('maxLength', 50))

        if not prompt:
            return jsonify({"error": "Prompt is required"}), 400

        print(f"Received request: prompt='{prompt}', temp={temperature}, max_len={max_length}")

        inputs = tokenizer.encode(prompt, return_tensors="pt").to(device)

        with torch.no_grad():
            outputs = model.generate(
                inputs,
                max_length=inputs.shape[1] + max_length,
                temperature=temperature,
                do_sample=True,
                top_k=50,
                top_p=0.95,
                pad_token_id=tokenizer.eos_token_id
            )

        generated_text = tokenizer.decode(outputs[0], skip_special_tokens=True)
        poem_only = generated_text[len(prompt):].strip()

        print(f"Generated poem: {poem_only}")
        return jsonify({"poem": poem_only})

    except Exception as e:
        print(f"Error during poem generation: {str(e)}")
        return jsonify({"error": "Failed to generate poem", "details": str(e)}), 500

if __name__ == '__main__':
    print("Initializing model...")
    load_model_and_tokenizer()
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000))) 